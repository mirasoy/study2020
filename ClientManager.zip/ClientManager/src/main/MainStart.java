package main;

import control.Cont;

public class MainStart {
	public MainStart() {
		new Cont();
	}
}
