package view;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import model.Dto;
import re.Res.*;

public class Input extends Screan{

	
	void play(){

		
		
		
		
		
	}
	
	
	
	
	
	
	
}
