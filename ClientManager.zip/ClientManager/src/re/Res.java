package re;

import control.Cont;
import model.Dto;
import view.Input;
import view.Screan;

public interface Res {
	Cont ctn = new Cont();
	 Input ip = new Input();
	 Dto dto = new Dto();
	 Data dt =  new Data();
		Screan scn = new Screan();
}
