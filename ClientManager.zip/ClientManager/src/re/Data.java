package re;

import java.util.HashMap;

public class Data {

	public static HashMap<String, Object> data = new HashMap<>();
}
